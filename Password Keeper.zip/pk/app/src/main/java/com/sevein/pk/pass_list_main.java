package com.sevein.pk;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by andi on 9/23/2016.
 */
public class pass_list_main extends Fragment{
    DatabaseHelper dbh;
    ListView listView;
    Context context;
    ListView lv;
    RelativeLayout llnorecords;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.pass_list_main,container,false);
        dbh = new DatabaseHelper(getActivity().getApplicationContext());
        llnorecords = (RelativeLayout) view.findViewById(R.id.llnorecords);
        lv = (ListView) view.findViewById(R.id.listView2);
        if(dbh.fetchAllRecords().size()==0){
            llnorecords.setVisibility(View.VISIBLE);
            lv.setVisibility(View.GONE);
        }else{
            llnorecords.setVisibility(View.GONE);
            lv.setVisibility(View.VISIBLE);
        }
        MainActivity mainActivity = (MainActivity)getActivity();
        MainActivity main = (MainActivity) getActivity();
        main.getSupportActionBar().setTitle("Password Keeper");
        //main.loadRecords();
        lv.setAdapter(main.adapterPasswords);
        return view;
    }
}

