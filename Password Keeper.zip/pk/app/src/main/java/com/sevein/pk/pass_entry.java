package com.sevein.pk;

import android.app.Fragment;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

/**
 * Created by andi on 9/23/2016.
 */
public class pass_entry extends Fragment {
    EditText txtTitile;
    boolean isPassShow = true;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity main = (MainActivity) getActivity();
        DatabaseHelper dbh = new DatabaseHelper(main.getApplicationContext());
        dbh.get(main.password_current_selected);
        View view = inflater.inflate(R.layout.pass_entry,container,false);
        EditText txtTitle = (EditText) view.findViewById(R.id.txtTitle);
        EditText txtSite = (EditText) view.findViewById(R.id.txtSite);
        EditText txtUsername = (EditText) view.findViewById(R.id.txtUsername);
        final EditText txtPassword = (EditText) view.findViewById(R.id.txtPassword);
        EditText txtNotes = (EditText) view.findViewById(R.id.txtNotes);
        final ImageView imgPassword = (ImageView) view.findViewById(R.id.imgPassword);
        txtTitle.setText(dbh.TITLE);
        txtSite.setText(dbh.SITE);
        txtUsername.setText(dbh.USERNAME);
        txtPassword.setText(dbh.PASSWORD);
        txtNotes.setText(dbh.NOTES);
        main.fab.setVisibility(View.GONE);

        imgPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable drawableHide = getResources().getDrawable(R.drawable.ic_visibility_off_black_24px);
                Drawable drawableShow = getResources().getDrawable(R.drawable.ic_remove_red_eye_black_24px);
                if (isPassShow) {
                    isPassShow = false;
                    txtPassword.setTransformationMethod(new HideReturnsTransformationMethod());
                    imgPassword.setBackground(drawableHide);
                } else {
                    isPassShow = true;
                    txtPassword.setTransformationMethod(new PasswordTransformationMethod());
                    imgPassword.setBackground(drawableShow);
                }

            }
        });
        return view;
    }
}
