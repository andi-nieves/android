package com.sevein.pk;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

/**
 * Created by ANDY on 2/9/2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String TABLE_PREFIX     = "password_keeper"; //table name
    public static final String DATABASE_NAME    = TABLE_PREFIX + "_db";
    public static final String TABLE_PASSWORD   = TABLE_PREFIX + "_tbl_passwords";
    public static final String TABLE_MASTER_PASSWORD   = TABLE_PREFIX + "_tbl_master_password";

    public static final int DATABASE_VERSION    = 1;
    /*** COLUMN / FIELDS **/
    public static final String FIELD_ID         = TABLE_PREFIX + "_id";
    public static final String FIELD_TITLE      = TABLE_PREFIX + "_title";
    public static final String FIELD_SITE       = TABLE_PREFIX + "_site";
    public static final String FIELD_USERNAME   = TABLE_PREFIX + "_user_name";
    public static final String FIELD_PASSWORD   = TABLE_PREFIX + "_password";
    public static final String FIELD_NOTES      = TABLE_PREFIX + "_notes";
    public static final String FIELD_STATUS     = TABLE_PREFIX + "_status";
    public static final String FIELD_TIME_STAMP = TABLE_PREFIX + "_time_stamp";
    /*** COLUMN / FIELDS **/
    public static final String TABLE_SETTINGS   = TABLE_PREFIX + "_tbl_settings";
    public Crypt encrypt    = new Crypt();
    public SecretKey key    = null;//encrypt.deriveKeyPad("p@ssw0rd201517");
    public int ID           = 0;
    public String TITLE     = "";
    public String SITE      = "";
    public String USERNAME  = "";
    public String PASSWORD  = "";
    public String NOTES     = "";
    public String STATUS    = "";
    public String TIME_STAMP = "";
    public long LAST_INSERTED_ID = 0;
    public String MASTER_PASSWORD = "";
    public static final String[] ALL_FIELDS = new String[]{
            DatabaseHelper.FIELD_ID,
            DatabaseHelper.FIELD_TITLE,
            DatabaseHelper.FIELD_SITE,
            DatabaseHelper.FIELD_USERNAME,
            DatabaseHelper.FIELD_PASSWORD,
            DatabaseHelper.FIELD_NOTES,
            DatabaseHelper.FIELD_STATUS,
            DatabaseHelper.FIELD_TIME_STAMP};

    public static final String DATABASE_CREATE_SQL = "CREATE TABLE " +
            TABLE_PASSWORD + "(" +
            FIELD_ID + " integer primary key autoincrement," +
            FIELD_TITLE + " text not null," +
            FIELD_SITE + " text not null," +
            FIELD_USERNAME + " text not null," +
            FIELD_PASSWORD + " text not null," +
            FIELD_NOTES + " text not null," +
            FIELD_STATUS + " text not null," +
            FIELD_TIME_STAMP + " text not null" +
            ")";
    public static final  String CREATE_MASTER_PASSWORD_TABLE = "CREATE TABLE " + TABLE_MASTER_PASSWORD +
            "(id integer primary key autoincrement,meta_key text not null,meta_value text not null)";
    private SQLiteDatabase database = this.getWritableDatabase();
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        key = encrypt.deriveKeyPad(dateNow());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE_SQL);
        db.execSQL(CREATE_MASTER_PASSWORD_TABLE);
        Log.d("DATABASE", DATABASE_CREATE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PASSWORD );
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MASTER_PASSWORD );
        onCreate(db);
    }
    public String get_metadata(String meta_key){
        String result = "";
        Cursor cursor = database.query(TABLE_MASTER_PASSWORD, new String[]{"meta_key", "meta_value"}, "meta_key = ?", new String[]{meta_key}, null, null, null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            result = cursor.getString(1);
        }
        return result;
    }
    public void update_meta(String meta_key,String meta_value){
        String value = get_metadata(meta_key);
        ContentValues contentValues = new ContentValues();
        contentValues.put("meta_key",meta_key);
        contentValues.put("meta_value",meta_value);
        if(value.isEmpty()){
            database.insert(TABLE_MASTER_PASSWORD,null,contentValues);
        }else{
            database.update(TABLE_MASTER_PASSWORD,contentValues,"meta_key = ?",new String[]{meta_key});
        }
    }
    public String getMasterPassword(){
        return get_metadata("MASTER_PASSWORD");
    }
    public void updateMasterPasword(String password){
        ContentValues contentValues = new ContentValues();
        contentValues.put("meta_key","MASTER_PASSWORD");
        contentValues.put("meta_value",password);
        database.insert(TABLE_MASTER_PASSWORD,null,contentValues);
    }
    public String dateNow(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        //System.out.println(dateFormat.format(date)); //2014/08/06 15:59:48
        return  dateFormat.format(date);
    }
    public List<PasswordArray> fetchAllRecords(){
        List<PasswordArray> passwordArrays = new ArrayList<PasswordArray>();

        Cursor cursor = database.query(DatabaseHelper.TABLE_PASSWORD,ALL_FIELDS, FIELD_STATUS + " = ? ORDER BY " + FIELD_TIME_STAMP + " desc",new String[]{"active"},null,null,null,null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            //if( cursor.getString(6) == "active"){
            PasswordArray pa = new PasswordArray();
            pa.setId(cursor.getInt(0));
            pa.setTitle(cursor.getString(1));
            pa.setSite(cursor.getString(2));
            pa.setUsername(cursor.getString(3));
            pa.setPassword(cursor.getString(4));
            pa.setNotes(cursor.getString(5));
            pa.setStatus(cursor.getString(6));
            pa.setTime_stamp(cursor.getString(7));
            passwordArrays.add(pa);
            //}
            cursor.moveToNext();

        }
        return passwordArrays;
    }
    public List<PasswordArray> fetchAllTrashRecords(){
        List<PasswordArray> passwordArrays = new ArrayList<PasswordArray>();

        Cursor cursor = database.query(DatabaseHelper.TABLE_PASSWORD,ALL_FIELDS, FIELD_STATUS + " = ?",new String[]{"trash"},null,null,null,null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            //if( cursor.getString(6) == "active"){
            PasswordArray pa = new PasswordArray();
            pa.setId(cursor.getInt(0));
            pa.setTitle(cursor.getString(1));
            pa.setSite(cursor.getString(2));
            pa.setUsername(cursor.getString(3));
            pa.setPassword(cursor.getString(4));
            pa.setNotes(cursor.getString(5));
            pa.setStatus(cursor.getString(6));
            pa.setTime_stamp(cursor.getString(7));
            passwordArrays.add(pa);
            //}
            cursor.moveToNext();

        }
        return passwordArrays;
    }
    public void get(int id){
        if(id==0){
            return;
        }
        Cursor cursor = database.query(TABLE_PASSWORD,ALL_FIELDS,FIELD_ID + " = ?",new String[]{String.valueOf(id)},null,null,null);
        cursor.moveToFirst();
        TITLE = cursor.getString(1);
        SITE = cursor.getString(2);
        USERNAME = cursor.getString(3);
        PASSWORD = encrypt.decryptNoSalt(cursor.getString(4),key);
        NOTES = cursor.getString(5);
    }
    public void Save(){
        ContentValues values = new ContentValues();
       // if(CheckIdDataExist(TITLE)){
        //    for
       // }
        values.put(DatabaseHelper.FIELD_TITLE,TITLE);
        values.put(DatabaseHelper.FIELD_SITE,SITE);
        values.put(DatabaseHelper.FIELD_USERNAME,USERNAME);
        values.put(DatabaseHelper.FIELD_PASSWORD,encrypt.encrypt(PASSWORD,key));
        values.put(DatabaseHelper.FIELD_NOTES,NOTES);
        values.put(DatabaseHelper.FIELD_STATUS, "active");
        values.put(DatabaseHelper.FIELD_TIME_STAMP, dateNow());

        long lastInsertId = 0;
        if(ID!=0){
            database.update(DatabaseHelper.TABLE_PASSWORD,values,DatabaseHelper.FIELD_ID + " = ?",new String[] {Integer.toString(ID)});
        }else {
            //values.put(DatabaseHelper.FIELD_STATUS,"active");
            lastInsertId = database.insert(DatabaseHelper.TABLE_PASSWORD,null,values);
        }
        LAST_INSERTED_ID = lastInsertId;
    }
    public void DeleteItemById(int id){
       // database.execSQL("DELETE FROM " + TABLE_PASSWORD + " WHERE " + FIELD_ID + " = " + id);
        database.execSQL("UPDATE " + TABLE_PASSWORD + " SET " + FIELD_STATUS + " = 'trash' WHERE " + FIELD_ID + " = " + id);
    }
    public void DeletePermanentlyItemById(int id){
        database.execSQL("DELETE FROM " + TABLE_PASSWORD + " WHERE " + FIELD_ID + " = " + id);
       // database.execSQL("UPDATE " + TABLE_PASSWORD + " SET " + FIELD_STATUS + " = 'trash' WHERE " + FIELD_ID + " = " + id);
    }
    public Boolean CheckIdDataExist(String string){
        boolean result = false;
        Cursor c = database.query(DatabaseHelper.TABLE_PASSWORD,new String[]{ FIELD_TITLE },FIELD_TITLE + " = ? ", new String[] { string},null,null,null);
        if(c.getCount()>0){
            result = true;
        }
        return result;
    }
}
