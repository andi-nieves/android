package com.sevein.pk;

import android.app.Fragment;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

/**
 * Created by andi on 9/26/2016.
 */
public class login extends Fragment {
    boolean isPassShown = false;
    boolean isPassShown2 = false;
    boolean isPassShown3 = false;
    boolean isPassShown4 = false;
    DatabaseHelper dbh = null;
    LinearLayout llLogin;
    LinearLayout llNewPassword;
    LinearLayout llSuccess;
    Crypt crypt = new Crypt();
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login,container,false);
        dbh = new DatabaseHelper(container.getContext());
        final MainActivity mainActivity = (MainActivity) container.getContext();
        llLogin = (LinearLayout) view.findViewById(R.id.llLogin);
        llNewPassword = (LinearLayout) view.findViewById(R.id.llNewPassword);
        llSuccess = (LinearLayout) view.findViewById(R.id.llSuccess);
        llNewPassword.setVisibility(View.INVISIBLE);
        llLogin.setVisibility(View.GONE);
        llSuccess.setVisibility(View.VISIBLE);
        final EditText txtMasterPassword = (EditText)view.findViewById(R.id.txtMasterPassword);
        final ImageView imgShowPassword = (ImageView) view.findViewById(R.id.imgLoginPassShow);
        final TextView btnLogin = (TextView) view.findViewById(R.id.btnLogin);

        final EditText txtNewPass = (EditText)view.findViewById(R.id.txtNewMasterPassword);
        final ImageView imgNewPass = (ImageView) view.findViewById(R.id.imgLoginPassShow2);

        final EditText txtConfirmPass = (EditText)view.findViewById(R.id.txtConfirmNewPassword);
        final ImageView imgConfirmPass = (ImageView) view.findViewById(R.id.imgLoginPassShow3);

        final EditText txtKey = (EditText)view.findViewById(R.id.txtSecretkey);
        final ImageView imgKey = (ImageView) view.findViewById(R.id.imgLoginPassShow4);


        TextView btnSave = (TextView) view.findViewById(R.id.btnSave);

        mainActivity.fab.setVisibility(View.GONE);

        llSuccess.setVisibility(View.GONE);
        if(dbh.getMasterPassword().isEmpty()){
            llLogin.setVisibility(View.GONE);
            llNewPassword.setVisibility(View.VISIBLE);
        }else{
            llLogin.setVisibility(View.VISIBLE);
        }
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = dbh.getMasterPassword();
                String secret_key = dbh.get_metadata("SECRET_KEY");
                SecretKey key = crypt.deriveKeyPad(secret_key);
                password = crypt.decryptNoSalt(password, key);
                //mainActivity.alert("["+secret_key + "]\n" + password + "\n" + txtMasterPassword.getText().toString());
                if(!password.equals(txtMasterPassword.getText().toString())){
                    mainActivity.alert("Password not match!");
                }else{
                    mainActivity.showPassList();
                    dbh.update_meta("ISLOGON","YES");
                }
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> err = new ArrayList<String>();
                if(txtNewPass.getText().toString().trim().isEmpty()){
                    err.add("Enter password");
                }
                if(txtConfirmPass.getText().toString().trim().isEmpty()){
                    err.add( "Confirm password");
                }
                if(txtNewPass.getText().toString().trim().length()<6){
                    err.add("Password must be 6 character or above");
                }
                if(!txtNewPass.getText().toString().equals(txtConfirmPass.getText().toString())){
                    err.add("Password not match");
                }

                if(err.size()>0){
                    mainActivity.alert("Entry Error\n\n" + TextUtils.join("\n", err));
                    return;
                }

                String _key = txtKey.getText().toString();
                _key = _key.isEmpty() ? "DEFAULT_KEY" + dbh.dateNow() : "S3cr3tK3y!s_" +_key;
                SecretKey key = crypt.deriveKeyPad(_key);
                dbh.update_meta("SECRET_KEY", _key);
                dbh.updateMasterPasword(crypt.encrypt(txtNewPass.getText().toString(), key));
                llNewPassword.setVisibility(View.GONE);
                llSuccess.setVisibility(View.VISIBLE);
                llSuccess.animate().alpha(1).setDuration(2000).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        llLogin.setVisibility(View.VISIBLE);
                        llNewPassword.setVisibility(View.GONE);
                        llSuccess.setVisibility(View.GONE);
                    }
                });


            }
        });
        final Drawable showPass = getResources().getDrawable(R.drawable.ic_visibility_off_black_24px);
        final Drawable hidePass = getResources().getDrawable(R.drawable.ic_remove_red_eye_black_24px);
        imgShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isPassShown) {
                    imgShowPassword.setBackground(hidePass);
                    txtMasterPassword.setTransformationMethod(new PasswordTransformationMethod());
                    isPassShown = false;
                } else {
                    imgShowPassword.setBackground(showPass);
                    txtMasterPassword.setTransformationMethod(new HideReturnsTransformationMethod());
                    isPassShown = true;
                }
            }
        });

        imgNewPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isPassShown2) {
                    imgNewPass.setBackground(hidePass);
                    txtNewPass.setTransformationMethod(new PasswordTransformationMethod());
                    isPassShown2 = false;
                } else {
                    imgNewPass.setBackground(showPass);
                    txtNewPass.setTransformationMethod(new HideReturnsTransformationMethod());
                    isPassShown2 = true;
                }
            }
        });

        imgConfirmPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isPassShown3) {
                    imgConfirmPass.setBackground(hidePass);
                    txtConfirmPass.setTransformationMethod(new PasswordTransformationMethod());
                    isPassShown3 = false;
                } else {
                    imgConfirmPass.setBackground(showPass);
                    txtConfirmPass.setTransformationMethod(new HideReturnsTransformationMethod());
                    isPassShown3 = true;
                }
            }
        });
        imgKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPassShown4) {
                    imgKey.setBackground(hidePass);
                    txtKey.setTransformationMethod(new PasswordTransformationMethod());
                    isPassShown4 = false;
                } else {
                    imgKey.setBackground(showPass);
                    txtKey.setTransformationMethod(new HideReturnsTransformationMethod());
                    isPassShown4 = true;
                }
            }
        });
        return view;
    }
}
