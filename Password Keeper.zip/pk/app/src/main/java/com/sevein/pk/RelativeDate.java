
package com.sevein.pk;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.text.format.DateUtils;
import android.util.AttributeSet;

/**
 * A {@code TextView} that, given a reference time, renders that time as a time period relative to the current time.
 * @author Kiran Rao
 * @see #setReferenceTime(long)
 *
 */
public class RelativeDate {

    private long mReferenceTime;
    private String mText = "";
    private String mPrefix = "";
    private String mSuffix = "";
    private Handler mHandler = new Handler();
    private UpdateTimeRunnable mUpdateTimeTask;
    private boolean isUpdateTaskRunning = false;


    private void init(Context context, AttributeSet attrs) {
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs,
                R.styleable.RelativeTimeTextView, 0, 0);
        try {
           // mText = a.getString(R.styleable.RelativeTimeTextView_reference_time);
           //mPrefix = a.getString(R.styleable.RelativeTimeTextView_relative_time_prefix);
            //mSuffix = a.getString(R.styleable.RelativeTimeTextView_relative_time_suffix);

           // mPrefix = mPrefix == null ? "" : mPrefix;
           // mSuffix = mSuffix == null ? "" : mSuffix;
        } finally {
            a.recycle();
        }

        try {
            mReferenceTime = Long.valueOf(mText);
        } catch (NumberFormatException nfe) {
        	/*
        	 * TODO: Better exception handling
        	 */
            mReferenceTime = -1L;
        }

        setReferenceTime(mReferenceTime);

    }

    /**
     * Returns prefix
     * @return
     */
    public String getPrefix() {
        return this.mPrefix;
    }

    /**
     * String to be attached before the reference time
     * @param prefix
     *
     * Example:
     * [prefix] in XX minutes
     */
    public void setPrefix(String prefix) {
        this.mPrefix = prefix;
        updateTextDisplay();
    }

    /**
     * Returns suffix
     * @return
     */
    public String getSuffix() {
        return this.mSuffix;
    }

    /**
     * String to be attached after the reference time
     * @param suffix
     *
     * Example:
     * in XX minutes [suffix]
     */
    public void setSuffix(String suffix) {
        this.mSuffix = suffix;
        updateTextDisplay();
    }

    /**
     * Sets the reference time for this view. At any moment, the view will render a relative time period relative to the time set here.
     * <p/>
     * This value can also be set with the XML attribute {@code reference_time}
     * @param referenceTime The timestamp (in milliseconds since epoch) that will be the reference point for this view.
     */
    public void setReferenceTime(long referenceTime) {
        this.mReferenceTime = referenceTime;
        
        /*
         * Note that this method could be called when a row in a ListView is recycled.
         * Hence, we need to first stop any currently running schedules (for example from the recycled view.

        
        /*
         * Instantiate a new runnable with the new reference time
         */
        mUpdateTimeTask = new UpdateTimeRunnable(mReferenceTime);
        
        /*
         * Start a new schedule.
         */
        
        /*
         * Finally, update the text display.
         */
        updateTextDisplay();
    }

    public String updateTextDisplay() {
        /*
         * TODO: Validation, Better handling of negative cases
         */
        if (this.mReferenceTime == -1L) {

        }
            return mPrefix + getRelativeTimeDisplayString() + mSuffix;
    }

    private CharSequence getRelativeTimeDisplayString() {
        long now = System.currentTimeMillis();
        long difference = now - mReferenceTime;
        CharSequence xdate = null;
        if (difference >0){
            if(difference>= DateUtils.WEEK_IN_MILLIS){
                xdate = (difference >= 0 &&  difference<= DateUtils.WEEK_IN_MILLIS) ?
                        "Just Now":
                        DateUtils.getRelativeTimeSpanString(
                                mReferenceTime,
                                now,
                                DateUtils.FORMAT_SHOW_DATE,
                                DateUtils.FORMAT_ABBREV_ALL);

                return  xdate;
            }
            if(difference>= DateUtils.DAY_IN_MILLIS){
                xdate = (difference >= 0 &&  difference<= DateUtils.MINUTE_IN_MILLIS) ?
                        "Just Now":
                        DateUtils.getRelativeTimeSpanString(
                                mReferenceTime,
                                now,
                                DateUtils.DAY_IN_MILLIS,
                                DateUtils.FORMAT_ABBREV_WEEKDAY);

                return  xdate;
            }
        }
        xdate = (difference >= 0 &&  difference<= DateUtils.MINUTE_IN_MILLIS) ?
                "Just Now":
                DateUtils.getRelativeTimeSpanString(
                        mReferenceTime,
                        now,
                        DateUtils.MINUTE_IN_MILLIS,
                        DateUtils.FORMAT_ABBREV_RELATIVE);
        return xdate;

       /* xdate = (difference >= 0 &&  difference<=DateUtils.MINUTE_IN_MILLIS) ?
                "Just Now" + String.valueOf(difference):
                DateUtils.getRelativeTimeSpanString(
                        mReferenceTime,
                        now,
                        DateUtils.MINUTE_IN_MILLIS,
                        DateUtils.FORMAT_ABBREV_RELATIVE)*/
    }

    private class UpdateTimeRunnable implements Runnable {

        private long mRefTime;

        UpdateTimeRunnable(long refTime){
            this.mRefTime = refTime;
        }

        @Override
        public void run() {
            long difference = Math.abs(System.currentTimeMillis() - mRefTime);
            long interval = DateUtils.MINUTE_IN_MILLIS;
            if (difference > DateUtils.WEEK_IN_MILLIS) {
                interval = DateUtils.WEEK_IN_MILLIS;
            } else if (difference > DateUtils.DAY_IN_MILLIS) {
                interval = DateUtils.DAY_IN_MILLIS;
            } else if (difference > DateUtils.HOUR_IN_MILLIS) {
                interval = DateUtils.HOUR_IN_MILLIS;
            }
            updateTextDisplay();
            mHandler.postDelayed(this, interval);

        }

    }
}
