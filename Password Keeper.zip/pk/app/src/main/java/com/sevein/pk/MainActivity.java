package com.sevein.pk;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    boolean isLogin = false;
    Toolbar toolbar;
    Menu main_menu;
    FloatingActionButton fab;
    ListView lvPass;
    Context context = this;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    int current_fragment = 0;
    DatabaseHelper dbh = null;
    pass_entry passEntry;
    List<PasswordArray> listPasswords = null;
    ArrayList<PasswordArray> arrayListPasswords = null;//(ArrayList<PasswordArray>) listPasswords;
    PasswordAdapter adapterPasswords = null;//new PasswordAdapter(context,arrayListPasswords);
    public int main = 0;
    public int entry = 1;
    int last_sort_method = 0;
    public int password_current_selected = 0;
    LinearLayout linearSearch;
    AutoCompleteTextView txtSearch;
    Animation slideUp;
    Animation slideDown;
    LinearLayout linearLoginCaption;

    public void loadRecords() {
        dbh = new DatabaseHelper(context);
        listPasswords = dbh.fetchAllRecords();
        arrayListPasswords = (ArrayList<PasswordArray>) listPasswords;
        adapterPasswords = new PasswordAdapter(context, arrayListPasswords);
    }

    public void sortPass(int method) {
        last_sort_method = method;
        switch (method) {
            case 0:
                adapterPasswords.sort(new Comparator<PasswordArray>() {
                    @Override
                    public int compare(PasswordArray lhs, PasswordArray rhs) {
                        return lhs.getTitle().compareTo(rhs.getTitle());
                    }
                });
                break;
            case 1:
                adapterPasswords.sort(new Comparator<PasswordArray>() {
                    @Override
                    public int compare(PasswordArray lhs, PasswordArray rhs) {
                        return rhs.getTitle().compareTo(lhs.getTitle());
                    }
                });
                break;
            case 2:
                adapterPasswords.sort(new Comparator<PasswordArray>() {
                    @Override
                    public int compare(PasswordArray lhs, PasswordArray rhs) {
                        return lhs.getTime_stamp().compareTo(rhs.getTime_stamp());
                    }
                });
                break;
            case 3:
                adapterPasswords.sort(new Comparator<PasswordArray>() {
                    @Override
                    public int compare(PasswordArray lhs, PasswordArray rhs) {
                        return rhs.getTime_stamp().compareTo(lhs.getTime_stamp());
                    }
                });
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (current_fragment != main) {
            if (isLogin) {
                current_fragment = 0;
                (getSupportActionBar()).setDisplayHomeAsUpEnabled(false);
                (getSupportActionBar()).setDefaultDisplayHomeAsUpEnabled(false);
                //loadRecords();
                showPassList();
                return;
            }
        } else {
            super.onBackPressed();
        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (current_fragment != 0) {
                if (isLogin) {
                    current_fragment = 0;
                    (getSupportActionBar()).setDisplayHomeAsUpEnabled(false);
                    (getSupportActionBar()).setDefaultDisplayHomeAsUpEnabled(false);
                    //loadRecords();
                    showPassList();
                    return false;
                }
            } else {
                return super.onKeyDown(keyCode, event);
            }
        } else {

        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadRecords();

        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar = toolbar;
        linearLoginCaption = (LinearLayout) findViewById(R.id.llLogin);
        toolbar.setTitle("Password Vault");
        setSupportActionBar(toolbar);
        fragmentManager = getFragmentManager();
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                current_fragment = 1;
                (getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
                (getSupportActionBar()).setDefaultDisplayHomeAsUpEnabled(true);
                main_menu.getItem(0).setVisible(false);
                main_menu.getItem(1).setVisible(false);
                main_menu.getItem(3).setVisible(false);
                main_menu.getItem(2).setVisible(true);
                passEntry = new pass_entry();
                password_current_selected = 0;
                fragmentManager.beginTransaction().replace(R.id.fragment, passEntry).setTransition(fragmentTransaction.TRANSIT_ENTER_MASK).commit();
                Log.d("Hey", "Click");
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPassList();
            }
        });
        linearSearch = (LinearLayout) findViewById(R.id.linearSearch);
        slideUp = AnimationUtils.loadAnimation(context,R.anim.slide_up);
        slideDown = AnimationUtils.loadAnimation(context,R.anim.slide_down);
        if(dbh.get_metadata("ISLOGON").equals("YES")){
            showPassList();


        }else{
            showLogin();
        }
    }

    public void showLogin(){
        current_fragment = 0;
        login _login = new login();
        fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragment,_login).setTransition(fragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();

    }
    public void hideMenus(){
        if(main_menu==null){
            return;
        }
        main_menu.getItem(0).setVisible(false);
        main_menu.getItem(1).setVisible(false);
        main_menu.getItem(3).setVisible(false);
        main_menu.getItem(2).setVisible(false);
    }
    public void showPassList(){
        linearLoginCaption.setVisibility(View.GONE);
        fab.setVisibility(View.VISIBLE);
        (getSupportActionBar()).setDisplayHomeAsUpEnabled(false);
        (getSupportActionBar()).setDefaultDisplayHomeAsUpEnabled(false);
        if(main_menu != null){
            main_menu.getItem(0).setVisible(true);
            main_menu.getItem(1).setVisible(true);
            main_menu.getItem(3).setVisible(true);
            main_menu.getItem(2).setVisible(false);
        }

        pass_list_main passListMain = new pass_list_main();
        fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragment,passListMain).setTransition(fragmentTransaction.TRANSIT_ENTER_MASK).commit();
        txtSearch = (AutoCompleteTextView) findViewById(R.id.txtSearch);
        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapterPasswords.filter(txtSearch.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    public void showPassEntry(int id){
        password_current_selected = id;
        current_fragment = 1;
        (getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        (getSupportActionBar()).setDefaultDisplayHomeAsUpEnabled(true);
        //MenuInflater mi = getMenuInflater();
        //onCreateOptionsMenu(main_menu);
        main_menu.getItem(0).setVisible(false);
        main_menu.getItem(1).setVisible(false);
        main_menu.getItem(3).setVisible(false);
        main_menu.getItem(2).setVisible(true);
        pass_entry passEntry = new pass_entry();
        fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragment,passEntry).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        main_menu = menu;
        if(dbh.fetchAllRecords().size()==0){
            main_menu.getItem(0).setVisible(false);
            main_menu.getItem(1).setVisible(false);
            main_menu.getItem(3).setVisible(true);
            main_menu.getItem(2).setVisible(false);
        }else{
            main_menu.getItem(0).setVisible(true);
            main_menu.getItem(1).setVisible(true);
            main_menu.getItem(3).setVisible(true);
            main_menu.getItem(2).setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.action_settings:
                dbh.update_meta("ISLOGON","NO");
                showLogin();
                break;
            case R.id.action_search:
                //linearSearch.setVisibility(View.VISIBLE);
                //linearSearch.startAnimation(slideUp);
                if(linearSearch.getVisibility() == View.GONE){
                    linearSearch.setVisibility(View.VISIBLE);
                }else{
                    linearSearch.setVisibility(View.GONE);
                }

                break;
            case R.id.action_sort:
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                String sort_method[] = new String[] {"Title - Ascending","Title - Descending","Date - Ascending","Date - Descending"};
                alert.setTitle("Select sorting method");
                alert.setItems(sort_method, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sortPass(which);
                    }
                }).create().show();
                break;
            case R.id.action_done:
                EditText txtTitle = (EditText) findViewById(R.id.txtTitle);
                EditText txtSite = (EditText) findViewById(R.id.txtSite);
                EditText txtUsername = (EditText) findViewById(R.id.txtUsername);
                EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
                EditText txtNotes = (EditText) findViewById(R.id.txtNotes);
                Boolean err = false;
                if(txtTitle.getText().toString().trim().length()==0){
                    err = true;
                    txtTitle.setError("Title is required");
                }
                if(txtUsername.getText().toString().trim().length()==0){
                    err = true;
                    txtUsername.setError("Username is required");
                }
                if(txtPassword.getText().toString().trim().length()==0){
                    err = true;
                    txtPassword.setError("Password is required");
                }
                if(err){
                    alert("Please fill up all required fields!");
                    return false;
                }
                dbh.ID       = password_current_selected;
                dbh.TITLE    = txtTitle.getText().toString().trim();
                dbh.SITE     = txtSite.getText().toString().trim();
                dbh.USERNAME =  txtUsername.getText().toString().trim();
                dbh.PASSWORD =  txtPassword.getText().toString().trim();
                dbh.NOTES    =  txtNotes.getText().toString().trim();
                dbh.Save();
                Toast.makeText(context,"Record successfully saved!",Toast.LENGTH_LONG).show();
                loadRecords();
                showPassList();
                break;
        }
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void alert(String msg){
        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        alert.setMessage(msg);
        alert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).create().show();
    }
}
