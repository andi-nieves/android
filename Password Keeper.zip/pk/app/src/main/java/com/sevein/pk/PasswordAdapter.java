package com.sevein.pk;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ACER on 2/9/2016.
 */
public class PasswordAdapter extends ArrayAdapter<PasswordArray> {
    private Context context;
    private ArrayList<PasswordArray> pass_list;
    private ArrayList<PasswordArray> raw_list;

    ArrayList<PasswordArray> onSaveInstanceState() {
        int size = getCount();
        ArrayList<PasswordArray> items = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            items.add(getItem(i));
        }
        return pass_list;
    }

    public PasswordAdapter(Context context, ArrayList<PasswordArray> resource) {
        super(context, R.layout.pass_list_view_layout, resource);
        this.context = context;
        this.pass_list = resource;
        this.raw_list = resource;
       // MainActivity main = (MainActivity) context;
    }

    void onRestoreInstanceState(ArrayList<PasswordArray> items) {
        clear();
        addAll(items);
    }

    static class viewHolder {

        protected TextView title;
        protected TextView time;
        protected TextView subtitle;
        protected ImageView imgIcon;
        protected LinearLayout llHolder;
        protected LinearLayout lvAction;
        protected Button btnUpdate;
        protected Button btnDelete;
    }

    public void updateSelectAll() {
        MainActivity main = new MainActivity();
        main.toolbar = (Toolbar) ((MainActivity) getContext()).findViewById(R.id.toolbar);
        Menu menu = main.toolbar.getMenu();

        int i;
        int count = 0;
        for (i = 0; i < pass_list.size(); i++) {
            if (pass_list.get(i).getSelected()) {
                count++;
            }
        }
        if (count > 0) {
            menu.getItem(0).setVisible(true);
            menu.getItem(1).setVisible(true);
            menu.getItem(2).setVisible(false);
            menu.getItem(3).setVisible(false);
            main.toolbar.setBackgroundColor(Color.parseColor("#333333"));
            main.toolbar.setTitle(String.valueOf(count) + " Selected");
        } else {
            menu.getItem(2).setVisible(true);
            menu.getItem(3).setVisible(true);
            menu.getItem(0).setVisible(false);
            menu.getItem(1).setVisible(false);
            main.toolbar.setBackgroundColor(Color.RED);
            main.toolbar.setTitle("Password Keeper");
        }


    }

    public void filter(String str) {
        pass_list.clear();
        DatabaseHelper db = new DatabaseHelper(context);
        List<PasswordArray> plist = db.fetchAllRecords();
        ArrayList<PasswordArray> pass_list_raw = (ArrayList<PasswordArray>) plist;

        if (str.length() == 0) {
            pass_list.addAll(pass_list_raw);
        } else {
            str = str.toLowerCase();
            int i;
            for (i = 0; i < pass_list_raw.size(); i++) {
                if (pass_list_raw.get(i).getTitle().toLowerCase().startsWith(str)) {
                    pass_list.add(pass_list_raw.get(i));
                }
            }
        }
        notifyDataSetChanged();
    }


    @Override
    public View getView(final int position, final View view, final ViewGroup parent) {
        View myView = null;


        if (view == null) {
            final PasswordArray pa = getItem(position);
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            myView = inflater.inflate(R.layout.pass_list_view_layout, parent, false);
            myView = LayoutInflater.from(getContext()).inflate(R.layout.pass_list_view_layout, parent, false);
            final viewHolder viewHolder = new viewHolder();
            viewHolder.title = (TextView) myView.findViewById(R.id.tv_name);
            viewHolder.time = (TextView) myView.findViewById(R.id.tv_human_time);
            viewHolder.subtitle = (TextView) myView.findViewById(R.id.tview_url);
            viewHolder.imgIcon = (ImageView) myView.findViewById(R.id.img_thumb);
            viewHolder.llHolder = (LinearLayout) myView.findViewById(R.id.listRow);
            viewHolder.lvAction = (LinearLayout) myView.findViewById(R.id.lvActionbar);
            viewHolder.btnUpdate = (Button) myView.findViewById(R.id.btn_edit);
            viewHolder.btnDelete = (Button) myView.findViewById(R.id.btn_delete);
            viewHolder.lvAction.setVisibility(View.GONE);
            myView.setTag(viewHolder);
            viewHolder.llHolder.setTag(pass_list.get(position));
            //viewHolder.btnDelete.setTag("close");
        } else {
            myView = view;
            ((viewHolder) myView.getTag()).llHolder.setTag(pass_list.get(position));
        }
        RelativeDate rd = new RelativeDate();
        rd.setReferenceTime(Date.parse(pass_list.get(position).getTime_stamp()));
        final viewHolder holder = (viewHolder) myView.getTag();
        holder.imgIcon.setImageDrawable(setIcon(pass_list.get(position).getTitle()));
        holder.title.setText(pass_list.get(position).getTitle());
        holder.subtitle.setText(pass_list.get(position).getSite());
        holder.time.setText(rd.updateTextDisplay());

        if(pass_list.get(position).show_action){
            holder.lvAction.setVisibility(View.VISIBLE);
        }else{
            holder.lvAction.setVisibility(View.GONE);
        }
        holder.llHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = 0;
                for (i = 0; i < pass_list.size(); i++) {
                    pass_list.get(i).show_action = false;
                }
                pass_list.get(position).show_action = true;
                notifyDataSetChanged();
                holder.lvAction.setVisibility(View.VISIBLE);
            }
        });
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setMessage("Are you sure you want to delete [" + pass_list.get(position).getTitle() + "]");
                alert.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d("Delete click","hey");
                        DatabaseHelper db = new DatabaseHelper(context);
                        db.DeleteItemById(pass_list.get(position).getId());
                        pass_list.remove(position);
                        if(pass_list.size()==0){
                            MainActivity mainActivity = (MainActivity)getContext();
                            RelativeLayout rl = (RelativeLayout) mainActivity.findViewById(R.id.llnorecords) ;
                            rl.setVisibility(View.VISIBLE);
                            ListView lv = (ListView) mainActivity.findViewById(R.id.listView2);
                            lv.setVisibility(View.GONE);
                        }
                        notifyDataSetChanged();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).create().show();
            }
        });
        holder.btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity main = (MainActivity) context;
                main.showPassEntry(pass_list.get(position).getId());

            }
        });
        return myView;
    }
    public Drawable setIcon(String str){
        Character ch = str.toUpperCase().charAt(0);
        Drawable sample = null;
        if(ch == 'A'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_a);
        }else
        if(ch == 'B'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_b);
        }else
        if(ch == 'C'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_c);
        }else
        if(ch == 'D'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_d);
        }else
        if(ch == 'E'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_e);
        }else
        if(ch == 'F'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_f);
        }else
        if(ch == 'G'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_g);
        }else
        if(ch == 'H'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_h);
        }else
        if(ch == 'I'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_i);
        }else
        if(ch == 'J'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_j);
        }else
        if(ch == 'K'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_k);
        }else
        if(ch == 'L'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_l);
        }else
        if(ch == 'M'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_m);
        }else
        if(ch == 'N'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_n);
        }else
        if(ch == 'O'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_o);
        }else
        if(ch == 'P'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_p);
        }else
        if(ch == 'Q'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_q);
        }else
        if(ch == 'R'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_r);
        }else
        if(ch == 'S'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_s);
        }else
        if(ch == 'T'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_t);
        }else
        if(ch == 'U'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_u);
        }else
        if(ch == 'V'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_v);
        }else
        if(ch == 'W'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_w);
        }else
        if(ch == 'X'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_x);
        }else
        if(ch == 'Y'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_y);
        }else
        if(ch == 'Z'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_z);
        }else
        if(ch == '0'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_0);
        }else
        if(ch == '1'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_1);
        }else
        if(ch == '2'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_2);
        }else
        if(ch == '3'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_3);
        }else
        if(ch == '4'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_4);
        }else
        if(ch == '5'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_5);
        }else
        if(ch == '6'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_6);
        }else
        if(ch == '7'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_7);
        }else
        if(ch == '8'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_8);
        }else
        if(ch == '9'){
            sample = getContext().getResources().getDrawable(R.drawable.ic_9);
        }else{
            sample = getContext().getResources().getDrawable(R.drawable.ic_unknown);
        }

        return sample;
    }

}
