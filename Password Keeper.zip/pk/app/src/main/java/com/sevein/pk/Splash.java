package com.sevein.pk;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import android.os.Handler;
import java.util.logging.LogRecord;

/**
 * Created by andi on 9/28/2016.
 */
public class Splash extends AppCompatActivity {
    Handler handler = new Handler(Looper.getMainLooper());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
        DatabaseHelper dbh = new DatabaseHelper(getApplicationContext());

        final Intent i = new Intent(getApplicationContext(),MainActivity.class);
        if(dbh.get_metadata("ISLOGON")=="YES"){
            startActivity(i);
            finish();
        }
        Runnable r = new Runnable() {
            @Override
            public void run() {
                startActivity(i);
                finish();
            }
        };
        handler.postDelayed(r,2000);

    }
}
