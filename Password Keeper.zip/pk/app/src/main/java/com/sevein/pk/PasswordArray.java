package com.sevein.pk;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ACER on 2/9/2016.
 */
public class PasswordArray implements Parcelable {
    private int id;
    private String title;
    private String site;
    private String username;
    private String password;
    private String notes;
    private String status;
    private String time_stamp;
    private Boolean selected = false;
    public Boolean show_action = false;

    public void setId(int id){
        this.id = id;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public void setSite(String site){
        this.site  = site;
    }
    public void setUsername(String username){
        this.username = username;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public void setNotes(String notes){
        this.notes = notes;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public void setTime_stamp(String time_stamp){
        this.time_stamp = time_stamp;
    }
    public void setSelected(Boolean selected) {this.selected = selected;}
    public void setShow_action(Boolean show_action){this.show_action = show_action;}

    public int getId(){
        return this.id;
    }
    public String getTitle(){
        return this.title;
    }
    public String getSite(){
        return  this.site;
    }
    public String getUsername(){
        return this.username;
    }
    public String getPassword(){
        return this.password;
    }
    public String getNotes(){
        return this.notes;
    }
    public String getStatus(){
        return this.status;
    }
    public String getTime_stamp(){
        return this.time_stamp;
    }
    public Boolean getSelected() {return  this.selected;}
    public Boolean getShow_action() {return  this.show_action;}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }
    PasswordArray() {

        this.title = title;
        this.site = site;
        this.username = username;
        this.password = password;
        this.notes = notes;
        this.status = status;
        this.time_stamp = time_stamp;
        this.selected = selected;
        this.show_action = show_action;

    }
    protected PasswordArray(Parcel in) {

        this.title = in.readString();
        this.site = in.readString();
        this.username = in.readString();
        this.password = in.readString();
        this.notes = in.readString();
        this.status = in.readString();
        this.time_stamp = in.readString();
        this.selected = Boolean.valueOf(in.readString());
        this.show_action = Boolean.valueOf(in.readString());
    }
    @SuppressWarnings("unused")
    public static final Parcelable.Creator<PasswordArray> CREATOR = new Parcelable.Creator<PasswordArray>() {
        @Override
        public PasswordArray createFromParcel(Parcel in) {
            return new PasswordArray(in);
        }

        @Override
        public PasswordArray[] newArray(int size) {
            return new PasswordArray[size];
        }
    };
}
